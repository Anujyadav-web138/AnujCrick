package com.anujcrick.app

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject

class CricketViewModel : ViewModel() {
    private val _matches = MutableStateFlow<List<Match>>(emptyList())
    val matches: StateFlow<List<Match>> = _matches

    init {
        fetchMatches()
    }

    fun fetchMatches() {
        viewModelScope.launch {
            try {
                val client = OkHttpClient()
                val request = Request.Builder()
                    .url("https://cricket-live-score-api1.p.rapidapi.com/api/matchList")
                    .get()
                    .addHeader("X-RapidAPI-Key", "ff01143e-65a6-4c73-ab2a-9744f4e15406")
                    .addHeader("X-RapidAPI-Host", "cricket-live-score-api1.p.rapidapi.com")
                    .build()

                val response = client.newCall(request).execute()
                val json = JSONObject(response.body?.string() ?: "")
                val list = json.getJSONArray("matches")
                val result = mutableListOf<Match>()

                for (i in 0 until list.length()) {
                    val item = list.getJSONObject(i)
                    result.add(
                        Match(
                            team1 = item.optString("team1", ""),
                            team2 = item.optString("team2", ""),
                            score1 = item.optString("score1", ""),
                            score2 = item.optString("score2", ""),
                            status = item.optString("status", "")
                        )
                    )
                }
                _matches.value = result
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }
}