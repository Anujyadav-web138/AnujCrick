package com.anujcrick.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            AnujCrickTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    CricketApp()
                }
            }
        }
    }
}

@Composable
fun CricketApp(viewModel: CricketViewModel = viewModel()) {
    val matches by viewModel.matches.collectAsState()
    val scope = rememberCoroutineScope()

    Scaffold(topBar = {
        TopAppBar(title = { Text("AnujCrick - Live Scores") })
    }) { paddingValues ->
        Box(modifier = Modifier.padding(paddingValues)) {
            if (matches.isEmpty()) {
                CircularProgressIndicator(modifier = Modifier.padding(20.dp))
            } else {
                LazyColumn(modifier = Modifier.fillMaxSize()) {
                    items(matches) { match ->
                        Card(modifier = Modifier
                            .fillMaxWidth()
                            .padding(8.dp)) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text(text = "${match.team1} vs ${match.team2}", style = MaterialTheme.typography.titleMedium)
                                Text(text = "Score: ${match.score1} / ${match.score2}")
                                Text(text = "Status: ${match.status}", style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                }
            }
        }
    }
}