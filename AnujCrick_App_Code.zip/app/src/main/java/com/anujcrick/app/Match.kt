package com.anujcrick.app

data class Match(
    val team1: String,
    val team2: String,
    val score1: String,
    val score2: String,
    val status: String
)